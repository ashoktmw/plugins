#!/usr/bin/env bash

git clone https://github.com/magefile/mage
cd mage
go run bootstrap.go
