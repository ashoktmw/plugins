#!/usr/bin/env bash

export GOPATH=$HOME/go
$GOPATH/bin/mage -v
