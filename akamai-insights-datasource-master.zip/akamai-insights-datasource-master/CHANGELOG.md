# Changelog

## 1.0.0 (Released)

Initial release.

## 1.0.1
Bugs fixed:
Fix vector-to-array-data-grafana9
DPS-31123 Fix operators list 
