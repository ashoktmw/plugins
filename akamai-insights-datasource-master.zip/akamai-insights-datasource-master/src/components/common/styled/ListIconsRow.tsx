import styled from '@emotion/styled';

export const ListIconsRow = styled.div`
    display: flex;
    align-items: center;
    height: 32px;
`;
